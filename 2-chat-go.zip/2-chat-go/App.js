import React, { useState, useEffect, useCallback } from 'react';
import { View, ActivityIndicator, Alert } from 'react-native';
import { GiftedChat } from 'react-native-gifted-chat';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, deleteDoc, doc } from 'firebase/firestore';


// Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCQHwa2OPxjCGq74J3lt83bZCyUvfv82xc",
  authDomain: "me-you-bfe0a.firebaseapp.com",
  projectId: "me-you-bfe0a",
  storageBucket: "me-you-bfe0a.appspot.com",
  messagingSenderId: "743096728831",
  appId: "1:743096728831:web:f706207cc05bc17c8420ca",
  measurementId: "G-K380Y7M9HZ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const messagesRef = collection(db, 'messages');

export default function App() {
  const [messages, setMessages] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load or set user
  useEffect(() => {
    const initUser = async () => {
      let storedUser = await AsyncStorage.getItem('user');
      if (!storedUser) {
        storedUser = JSON.stringify({
          _id: Date.now().toString(),
          name: 'User ' + Math.floor(Math.random() * 1000)
        });
        await AsyncStorage.setItem('user', storedUser);
      }
      setUser(JSON.parse(storedUser));
      setLoading(false);
    };
    initUser();
  }, []);

  // Listen to Firestore messages
  useEffect(() => {
    const q = query(messagesRef, orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, snapshot => {
      const now = new Date();
      const newMessages = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        const createdAt = data.createdAt?.toDate?.();
        if (createdAt && now - createdAt > 86400000) {
          deleteDoc(doc(messagesRef, docSnap.id));
        } else {
          newMessages.push({
            _id: docSnap.id,
            text: data.text,
            createdAt: createdAt,
            user: data.user
          });
        }
      });
      setMessages(newMessages);
    });
    return () => unsubscribe();
  }, []);

  // Send new message
  const onSend = useCallback(async (messages = []) => {
    const { _id, createdAt, text, user } = messages[0];
    await addDoc(messagesRef, {
      _id,
      createdAt,
      text,
      user
    });
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <GiftedChat
      messages={messages}
      onSend={messages => onSend(messages)}
      user={user}
      showAvatarForEveryMessage
      alwaysShowSend
    />
  );
}